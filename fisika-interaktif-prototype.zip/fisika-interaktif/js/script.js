const mass = document.getElementById("mass");
const force = document.getElementById("force");
const massValue = document.getElementById("massValue");
const forceValue = document.getElementById("forceValue");
const acceleration = document.getElementById("acceleration");
const object = document.getElementById("object");

function updateSimulation(){
  const m = Number(mass.value);
  const f = Number(force.value);
  const a = f / m;
  massValue.textContent = m;
  forceValue.textContent = f;
  acceleration.textContent = a.toFixed(2);
  object.style.transform = `translateX(${Math.min(a * 8, 170)}px)`;
}
mass.addEventListener("input", updateSimulation);
force.addEventListener("input", updateSimulation);
updateSimulation();

const answers = document.querySelectorAll(".answers button");
const result = document.getElementById("quizResult");
const reset = document.getElementById("resetQuiz");

answers.forEach(button => {
  button.addEventListener("click", () => {
    answers.forEach(b => b.disabled = true);
    if(button.dataset.correct === "true"){
      button.classList.add("correct");
      result.textContent = "✓ Benar! ΣF = m × a adalah rumus Hukum Newton II.";
    }else{
      button.classList.add("wrong");
      result.textContent = "✗ Belum tepat. Coba ingat kembali hubungan gaya, massa, dan percepatan.";
      answers.forEach(b => { if(b.dataset.correct === "true") b.classList.add("correct"); });
    }
  });
});

reset.addEventListener("click", () => {
  answers.forEach(b => { b.disabled = false; b.classList.remove("correct","wrong"); });
  result.textContent = "";
});
