# Fisika Interaktif — Hukum Newton

Prototype website media pembelajaran fisika untuk tugas Multimedia.

## Fitur
- Beranda
- Materi Hukum Newton I, II, dan III
- Simulasi Hukum Newton II
- Contoh soal
- Kuis interaktif
- Profil media
- Responsive untuk HP dan desktop

## Cara menjalankan
Buka `index.html` di browser.

## Upload ke GitHub
1. Buat repository baru di GitHub, misalnya `fisika-interaktif`.
2. Upload seluruh isi folder ini.
3. Pastikan `index.html` berada di folder utama repository.
4. Jika ingin dijadikan website, aktifkan GitHub Pages pada Settings → Pages.
